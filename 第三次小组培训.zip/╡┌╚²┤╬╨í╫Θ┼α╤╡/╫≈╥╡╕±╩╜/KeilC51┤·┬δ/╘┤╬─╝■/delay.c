#include"delay.h"
#include <REGX51.H>


void delay(unsigned int X)
{
	unsigned char i, j;
	while(X--)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
	}
}
