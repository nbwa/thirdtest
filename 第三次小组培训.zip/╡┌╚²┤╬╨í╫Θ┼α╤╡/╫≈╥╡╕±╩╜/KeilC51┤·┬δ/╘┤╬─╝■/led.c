#include"led.h"
#include <REGX51.H>
#include"delay.h"

void ledfloat()
{
	int k;
	for(k=0;k<8;k++)
	{
		P2=~(0X01<<k);
		delay(500);
	}

}

