#include <REGX51.H>
#include"key.h"
#include"delay.h"

char key()
{
    char keynum=0;
	
	  if(P3_1==0)
		{
		delay(20);
			while(P3_1==0);
			delay(20);
			keynum=1;
		}
		
		
			  if(P3_0==0)
		{
		delay(20);
			while(P3_0==0);
			delay(20);
			keynum=2;
		}
		
			  if(P3_2==0)
		{
		delay(20);
			while(P3_2==0);
			delay(20);
			keynum=3;
		}
		
		 if(P3_3==0)
		{
			delay(20);
			while(P3_3==0);
			delay(20);
			keynum=4;
		}
		return keynum;
		
}