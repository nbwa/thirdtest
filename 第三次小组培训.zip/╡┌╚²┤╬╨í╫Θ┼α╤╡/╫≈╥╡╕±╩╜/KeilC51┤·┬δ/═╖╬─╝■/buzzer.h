#ifndef __BUZZER_H__
#define __BUZZER_H__

void Buzzerout( int ms);
void Buzzer_Delay500us();
#endif
