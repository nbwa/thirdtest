#ifndef __NIXIE_H__
#define __NIXIE_H__

void nixie();

#endif
